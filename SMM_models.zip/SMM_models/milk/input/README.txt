PLEASE DOWNLOAD AND COPY THE FORCING NETCDF FILE, "RavenInput_V4.nc", HERE.
You can find a copy of this file at:
https://drive.google.com/file/d/1SXuMMbNPUgF_BWalM0qYuwvGavvBLzsA/view?usp=sharing