options(repos = c(CRAN = "https://cloud.r-project.org/"))
packages <- c("data.table", "RavenR", "xts")
id<-which(!(packages %in% installed.packages()))
if(length(id)>0) for(i in 1:length(id)) install.packages(packages[i]) 
library(data.table)
library(RavenR)
library(xts)
moving_window_abs_error <- function(sim, obs, weights, n)
{
  if(length(sim) != length(obs) || length(sim) != length(weights)) {
    stop("sim, obs, and weights must all be the same length.")
  }
  T <- length(sim)  # Total length of the time series
  total_weighted_error <- 0  # Initialize the sum of weighted errors
  total_weight <- 0          # Initialize the sum of weights
  for (t in n:T)
  {
    window_indices <- (t - n + 1):t
    window_weight_sum <- sum(weights[window_indices])
    if (window_weight_sum > 0)
    {
      window_error <- sum(weights[window_indices] * abs(sim[window_indices] - obs[window_indices]),na.rm = T)
      total_weighted_error <- total_weighted_error + window_error
      total_weight <- total_weight + window_weight_sum
    }
  }
  if (total_weight > 0)
  {
    overall_diag <- total_weighted_error / total_weight
  } else {
    overall_diag <- NA  # Return NA if no data points were included in any window
  }
  return(overall_diag)
}
outdir<-"out"
hydro_file<-file.path(outdir,"Hydrographs.csv")
diag_file<-file.path(outdir,"Diagnostics.csv")
diag<-read.csv(diag_file)
hydro<-read.csv(hydro_file)
target<-as.numeric(gsub(".*\\[([0-9]+)\\].*", "\\1", diag$observed_data_series))
obj<-rep(NA,length(target))
weight<-rvn_rvt_read(list.files("input/obs/",full.names = T)[grep(target[1],list.files("input/obs/"))])$rvt_xts
for(i in 1:length(target))
{
  id<-grep(target[i],colnames(hydro))
  sim<-hydro[,id[1]]
  obs<-hydro[,id[2]]
  if(any(is.na(sim)))
  {
    obj[i]<-1e5
  }else{
    obj[i]<-moving_window_abs_error(sim,obs,weight,7)
  }
}
diag$X<-NULL
diag$'DIAG_ABSERR_RUN[7]'<-obj
write.csv(diag,file = diag_file,row.names = F)